
<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
    <div id="stadium">
        <h1>Baseball News</h1>
        <h2>...because we know</h2>
        <div class="square"></div>
        <div class="square2">
            <nav class="navigation">
                <ul>
                    <li>
                        <a href= <?php echo e(url('playersRanking/')); ?>>Players</a>
                    </li>
                </ul>
            </nav>
            <img id = "photoplayer" height="150" width="200" src= <?php echo e(asset('/'.$player->photoplayer)); ?>>
            <img id ="photoflag" height="150" width="200" src= <?php echo e(asset('/'.$player->photonationality)); ?>>
            <h3><?php echo e($player->name); ?></h3>
                <table class ="tablePlayer">
                    <tr>
                        <th>Age</th>
                        <th>Height(m)</th>
                        <th>Team</th>
                        <th>Ranking</th>
                        <th>Position</th>
                        <th>Nationality</th>
                    </tr>
                    <tr>
                        <td><?php echo e($player->age); ?></td>
                        <td><?php echo e($player->height); ?></td>
                        <td><?php echo e($player->team->name); ?></td>
                        <td><?php echo e($player->ranking); ?></td>
                        <td><?php echo e($player->position->name); ?></td>
                        <td><?php echo e($player->nationality); ?> </td>
                    </tr>
            </table>
        </div>
        <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
    </div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>






