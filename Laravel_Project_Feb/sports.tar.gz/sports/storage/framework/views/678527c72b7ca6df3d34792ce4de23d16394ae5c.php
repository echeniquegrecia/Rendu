<html>
<head>
  <title>Baseball News</title>
  <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
<div id="stadium">
  <h1>Baseball News</h1>
  <h2>...because we know</h2>
  <div class="square"></div>
  <div class="square2">
    <nav>
      <ul>
        <li><a href= <?php echo e(url('register/')); ?>>Sign-in</a><li>
        <li><a href= <?php echo e(url('login/')); ?>>Login</a><li>
        <li><a href= <?php echo e(url('playersRanking/')); ?>>Players</a><li>
        <li><a href= <?php echo e(url('teamRanking/')); ?>>Teams</a><li>
        <li><a href= <?php echo e(url('admin/')); ?>>Administrator</a><li>
        <li><a href= <?php echo e(url('logout/')); ?>>Logout</a><li>
      </ul>
    </nav>
    <table class ="tableAdmin">

      <form action="UpdatePosition" method="post">
        <?php echo e(csrf_field()); ?>

        <tr>
          <th>id</th>
          <td><input type="id" name="id" value="<?php echo e($val['id']); ?>"></td>
        </tr>
        <tr>
          <th>name</th>
          <td><input type="text" name="name" value="<?php echo e($val['name']); ?>"></td>
        </tr>
        <tr>
        <tr>
          <th></th>
          <th><input type="submit" name="up" id ="up" value="Update"></th>
        </tr>
        </tr>
      </form>
    </table>
    <p></p>

    <table class="tableAdmin2" >
      <thead class="thead-dark">

      <tr>
        <th scope="col">id</th>
        <th scope="col">name</th>
      </tr>
      </thead>
      <tbody>

      <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($vals->id); ?></th>
          <td><?php echo e($vals->name); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>


  </div>
  <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>
