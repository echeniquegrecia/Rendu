<html>
<head>
  <title>Baseball News</title>
  <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
  <script type="text/javascript" href=<?php echo e(asset('/js/time.js')); ?>></script>
</head>
<body>
<div id="stadium">
  <h1>Baseball News</h1>
  <h2>...because we know</h2>
  <div class="square"></div>
  <div class="square2">
    <nav>
      <ul>
        <li><a href= <?php echo e(url('match/')); ?>>Home</a></li>
      </ul>
    </nav>
    <table class ="tablefutureMatchesde">
      <tr>
        <th><a href="/team/<?php echo e($match->id_team_1); ?>"></a> </th>
        <th><?php echo e($tab1[$j]['t1']); ?> <?php echo e($match->score_team_1); ?></th>
        <th>-</th>
        <th><?php echo e($match->score_team_2); ?> <?php echo e($tab1[$j]['t2']); ?></th>
        <th><a href="/team/<?php echo e($match->id_team_2); ?>"></a></th>
      </tr>
      <tr>
      </tr>
      <tr>
        <td id = "match1" colspan="3">City:</td>
        <td colspan="4"><?php echo e($match->city); ?></td>
      </tr>
      <tr>
        <td id = "match2" colspan="3">Estimated Weather:</td>
        <td colspan="4" ><?php echo e($match->weather); ?></td>
      </tr>
      <tr>
        <td id = "match3" colspan="3">Date:</td>
        <td colspan="4" ><?php echo e($match->day_match); ?></td>
      </tr>
    </table>
  </div>
  <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>