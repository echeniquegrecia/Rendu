
<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
    <script type="text/javascript" href=<?php echo e(asset('/js/time.js')); ?>></script>
</head>
<body>
<div id="stadium">
    <h1>Baseball News</h1>
    <h2>...because we know</h2>
    <div class="square"></div>
    <div class="square2">
        <nav>
            <ul>
                <li><a href= <?php echo e(url('match/')); ?>><?php echo app('translator')->getFromJson('messages.Home'); ?></a><li>
            </ul>
        </nav>
        <h7><?php echo app('translator')->getFromJson('messages.Connect your passion for the baseball with us!'); ?></h7>
        <div class="loginsports">
            <form  method="POST" action="<?php echo e(route('login')); ?>">
                
                <?php echo e(csrf_field()); ?>

                <div class="loginemail" <?php echo e($errors->has('email') ? ' has-error' : ''); ?>>
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder=<?php echo app('translator')->getFromJson('messages.E-Mail Address'); ?> required autofocus>
                    <?php if($errors->has('email')): ?>
                        <div class="messageerror">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
                <br>
                <br>

                
                <div class="loginpassword"<?php echo e($errors->has('password') ? ' has-error' : ''); ?>>
                    <input id="password" type="password"  name="password" placeholder=<?php echo app('translator')->getFromJson('messages.Password'); ?> required>
                    <?php if($errors->has('password')): ?>
                        <div class="messageerror">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>

                
                <div class="submitlogin">
                    <button  type="submit"><?php echo app('translator')->getFromJson('messages.Login'); ?></button>
                </div>
            </form>
        </div>
    </div>
    <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>




