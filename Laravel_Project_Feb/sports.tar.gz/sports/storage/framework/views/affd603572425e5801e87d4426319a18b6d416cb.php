<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
<div id="stadium">
    <h1>Baseball News</h1>
    <h2>...because we know</h2>
    <div class="square"></div>
    <div class="square2">
        <nav>
            <ul>
                <li>
                    <a href= <?php echo e(url('match/')); ?>>Home</a>
                </li>
            </ul>
        </nav>
        <table class="tableTeams">
            <tr>
                <th>Name</th>
                <th>Logo</th>
                <th>Ranking</th>
            </tr>
            <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href= <?php echo e(url('team/'.$key->id)); ?>><?php echo e($key->name); ?> </a></td>
                    <td><img height="100" width="100" src= <?php echo e(asset('/'.$key->logo)); ?>  ></td>
                    <td><?php echo e($key->ranking); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </table>
    </div>
    <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>





