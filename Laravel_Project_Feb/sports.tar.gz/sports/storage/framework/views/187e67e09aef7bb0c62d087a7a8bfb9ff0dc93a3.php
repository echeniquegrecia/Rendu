<html>
<head>
  <title>Baseball News</title>
  <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
<div id="stadium">
  <h1>Baseball News</h1>
  <h2>...because we know</h2>
  <div class="square"></div>
  <div class="square2">
    <nav>
      <ul>
        <li><a href= <?php echo e(url('register/')); ?>>Sign-in</a><li>
        <li><a href= <?php echo e(url('login/')); ?>>Login</a><li>
        <li><a href= <?php echo e(url('playersRanking/')); ?>>Players</a><li>
        <li><a href= <?php echo e(url('teamRanking/')); ?>>Teams</a><li>
        <li><a href= <?php echo e(url('admin/')); ?>>Administrator</a><li>
        <li><a href= <?php echo e(url('logout/')); ?>>Logout</a><li>
      </ul>
    </nav>
    <table class="tableAdmin">


      <form action="UpdateMatch" method="post">
        <?php echo e(csrf_field()); ?>

        <tr>
          <th>id_team_1</th>
          <th><input type="text" name="id_team_1" value="<?php echo e($val['id_team_1']); ?>"></th>
        </tr>
        <tr>
          <th>id_team_2</th>
          <th><input type="text" name="id_team_2" value="<?php echo e($val['id_team_2']); ?>"></th>
        </tr>
        <tr>
          <th>weather</th>
          <th><input type="text" name="weather" value="<?php echo e($val['weather']); ?>"></th>
        </tr>
        <tr>
          <th>city</th>
          <th><input type="text" name="city" value="<?php echo e($val['city']); ?>"></th>
        </tr>
        <tr>
          <th>score_team_1</th>
          <th><input type="text" name="score_team_1" value="<?php echo e($val['score_team_1']); ?>"></th>
        </tr>
        <tr>
          <th>score_team_2</th>
          <th><input type="text" name="score_team_2" value="<?php echo e($val['score_team_2']); ?>"></th>
        </tr>
        <tr>
          <th>created_at</th>
          <th><input type="text" name="created_at" value="<?php echo e($val['created_at']); ?>"></th>
        </tr>
        <tr>
          <th>updated_at</th>
          <th><input type="text" name="updated_at" value="<?php echo e($val['updated_at']); ?>"></th>
        </tr>
        <tr>
          <th>day_match</th>
          <th><input type="text" name="day_match" value="<?php echo e($val['day_match']); ?>"></th>
        </tr>
        <tr>
          <th></th>
          <th><input type="submit" name="up" id ="up" value="Update"></th>
        </tr>
      </form>

    </table>
    <p></p>

    <table class="tableAdmin2" >
      <thead class="thead-dark">
      <tr>
        <th scope="col">id</th>
        <th scope="col">id_team_1</th>
        <th scope="col">id_team_2</th>
        <th scope="col">weather</th>
        <th scope="col">city</th>
        <th scope="col">score_team_1</th>
        <th scope="col">score_team_2</th>
        <th scope="col">created_at</th>
        <th scope="col">updated_at</th>
        <th scope="col">day_match</th>
      </tr>
      </thead>
      <tbody>

      <?php $__currentLoopData = $match; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vals): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <th scope="row"><?php echo e($vals->id); ?></th>
          <td><?php echo e($vals->id_team_1); ?></td>
          <td><?php echo e($vals->id_team_2); ?></td>
          <td><?php echo e($vals->weather); ?></td>
          <td><?php echo e($vals->city); ?></td>
          <td><?php echo e($vals->score_team_1); ?></td>
          <td><?php echo e($vals->score_team_2); ?></td>
          <td><?php echo e($vals->created_at); ?></td>
          <td><?php echo e($vals->updated_at); ?></td>
          <td><?php echo e($vals->day_match); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>


  </div>
  <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>
