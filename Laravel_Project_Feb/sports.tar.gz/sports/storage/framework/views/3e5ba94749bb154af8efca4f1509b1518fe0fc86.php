<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
    <script type="text/javascript" href=<?php echo e(asset('/js/time.js')); ?>></script>
</head>
<body>
<div id="stadium">
    <h1>Baseball News</h1>
    <h2>...because we know</h2>
    <div class="square"></div>
    <div class="square2">
        <nav>
            <ul>
                <li><a href= <?php echo e(url('match/')); ?>><?php echo app('translator')->getFromJson('messages.Home'); ?></a><li>
            </ul>
        </nav>
        <h7><?php echo app('translator')->getFromJson('messages.Register your passion for the baseball with us!'); ?></h7>
        <div class="regisports">
            <form  method="POST" action="<?php echo e(route('register')); ?>">
                <?php echo e(csrf_field()); ?>

                
                <div class="reginame" <?php echo e($errors->has('name') ? ' has-error' : ''); ?>>
                    <input id="name" type="name"  name="name" value="<?php echo e(old('name')); ?>" placeholder=<?php echo app('translator')->getFromJson('messages.Name'); ?> required autofocus>
                    <?php if($errors->has('name')): ?>
                        <div class="messageerror">
                            <strong><?php echo e($errors->first('name')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
                <br>
                <br>

                
                <div class="regiemail" <?php echo e($errors->has('email') ? ' has-error' : ''); ?>>
                    <input id="email" type="email" name="email" value="<?php echo e(old('email')); ?>" placeholder=<?php echo app('translator')->getFromJson('messages.E-Mail Address'); ?> required autofocus>
                    <?php if($errors->has('email')): ?>
                        <div class="messageerror">
                            <strong><?php echo e($errors->first('email')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
                <br>
                <br>

                
                <div class="regipassword"<?php echo e($errors->has('password') ? ' has-error' : ''); ?>>
                    <input id="password" type="password"  name="password" placeholder=<?php echo app('translator')->getFromJson('messages.Password'); ?> required>
                    <?php if($errors->has('password')): ?>
                        <div class="messageerror">
                            <strong><?php echo e($errors->first('password')); ?></strong>
                        </div>
                    <?php endif; ?>
                </div>
                <br>
                <br>

                

                <div class="regiconfirm">
                    <input id="password-confirm" type="password"  name="password_confirmation" placeholder=<?php echo app('translator')->getFromJson('messages.Confirm Password'); ?> required>
                </div>

                
                <div class="regisubmit">
                    <button  type="submit"><?php echo app('translator')->getFromJson('messages.Register'); ?></button>
                </div>
            </form>
        </div>
    </div>
    <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>




