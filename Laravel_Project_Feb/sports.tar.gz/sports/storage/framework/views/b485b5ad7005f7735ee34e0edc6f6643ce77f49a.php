<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
<div id="stadium">
    <h1>Baseball News</h1>
    <h2>...because we know</h2>
    <div class="square"></div>
    <div class="square2">
        <nav>
            <ul>
                <li>
                    <a href= <?php echo e(url('teamRanking/')); ?>>Teams</a>
                </li>
            </ul>
        </nav>
        <img class="logoteam2" src= <?php echo e(asset('/'.$team->logo)); ?>>
        <table class="tableEachTeams">
            <tr>
                <th>Name</th>
                <th>City</th>
                <th>Ranking</th>
                
            </tr>
            <tr>
                <td><?php echo e($team->name); ?></td>
                <td><?php echo e($team->city); ?></td>
                <td><?php echo e($team->ranking); ?></td>
                </tr>
        </table>
        <table class="tableEachPlayers">
            <tr>
                <th>Players</th>
            </tr>
            <tr>
                <td><?php $__currentLoopData = $player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><a href= <?php echo e(url('players/'.$key->id)); ?>><?php echo e($key->name); ?></a><br><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>

            </tr>
        </table>


    </div>
    <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>





