<html>
<head>
  <title>Baseball News</title>
  <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
<div id="stadium">
  <h1>Baseball News</h1>
  <h2>...because we know</h2>
  <div class="square"></div>
  <div class="square2">
    <nav>
      <ul>
        <li><a href= <?php echo e(url('register/')); ?>>Sign-in</a><li>
        <li><a href= <?php echo e(url('login/')); ?>>Login</a><li>
        <li><a href= <?php echo e(url('playersRanking/')); ?>>Players</a><li>
        <li><a href= <?php echo e(url('teamRanking/')); ?>>Teams</a><li>
        <li><a href= <?php echo e(url('logout/')); ?>>Logout</a><li>
      </ul>
    </nav>
    <table class="tableAdmin">
      <tr>
        <form action="admin/deluser" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Delete an User</th>
          <td><select name="bet">
              <option value="0"></option>
              <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($users->id); ?>"> <?php echo e($users->id); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="del" class="btn btn-danger" value="DEL"></td>
        </form>
      </tr>
      <tr>
        <form action="admin/updateuserform" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Update a User</th>
          <td><select name="user">
              <option value="0"></option>
              <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $users): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value ="<?php echo e($users->id); ?>"><?php echo e($users->id); ?></option>>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="up" class="btn btn-info" value="UPDATE"></td>
        </form>
      </tr>
      <tr>
      </tr>
      <tr>
        <form action="admin/delmatch" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Delete a match</th>
          <td>  <select name="match">
              <option value="0"></option>
              <?php $__currentLoopData = $match; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($matches->id); ?>"> <?php echo e($matches->id); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="del" class="btn btn-danger" value="DEL"></td>
        </form>
      </tr>
      <tr>
        <form action="admin/updatematchform" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Update a match</th>
          <td> <select name="match">
              <option value="0"></option>
              <?php $__currentLoopData = $match; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matches): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value ="<?php echo e($matches->id); ?>"><?php echo e($matches->id); ?></option>>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="up" class="btn btn-info" value="UPDATE"></td>
        </form>
      </tr>
      <tr>
      </tr>
      <tr>
        <form action="delplayer" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Delete a player</th>
          <td><select name="player">
              <option value="0"></option>
              <?php $__currentLoopData = $player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $players): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($players->id); ?>"> <?php echo e($players->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="del" class="btn btn-danger" value="DEL"></td>
        </form>
      </tr>
      <tr>
        <form action="admin/updateplayerform" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Update a player</th>
          <td><select name="player">
              <option value="0"></option>
              <?php $__currentLoopData = $player; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $players): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value ="<?php echo e($players->id); ?>"><?php echo e($players->id); ?></option>>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="up" class="btn btn-info" value="UPDATE"></td>
        </form>

      </tr>
      <tr>
      </tr>
      <tr>
        <form action="delteam" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Delete a team</th>
          <td><select name="team">
              <option value="0"></option>
              <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($teams->id); ?>"> <?php echo e($teams->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="del" class="btn btn-danger" value="DEL"></td>
        </form>
      </tr>
      <tr>
        <form action="admin/updateteamform" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Update a Team</th>
          <td>  <select name="team">
              <option value="0"></option>
              <?php $__currentLoopData = $team; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teams): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value ="<?php echo e($teams->id); ?>"><?php echo e($teams->id); ?></option>>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="up" class="btn btn-info" value="UPDATE"></td>
        </form>
      </tr>
      <tr>
      </tr>
      <tr>
        <form action="delposition" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Delete a position</th>
          <td><select name="position">
              <option value="0"></option>
              <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $positions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($positions->id); ?>"> <?php echo e($positions->name); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td> <input type="submit" name="del" class="btn btn-danger" value="DEL"></td>
        </form>
      </tr>
      <tr>
        <form action="admin/updatepositionform" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Update a position</th>
          <td><select name="position">
              <option value="0"></option>
              <?php $__currentLoopData = $position; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $positions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value ="<?php echo e($positions->id); ?>"><?php echo e($positions->id); ?></option>>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td>  <input type="submit" name="up" class="btn btn-info" value="UPDATE"></td>
        </form>
      </tr>
      <tr>
      </tr>
      <tr>
        <form action="admin/delbet" method="post">
          <?php echo e(csrf_field()); ?>

          <th>Delete a bet</th>
          <td><select name="bet">
              <option value="0"></option>
              <?php $__currentLoopData = $bet; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bets): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($bets->id); ?>"> <?php echo e($bets->id); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></td>
          <td><input type="submit" name="del" class="btn btn-danger" value="DEL"></td>
        </form>
      </tr>
    </table>
  </div>
  <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>
