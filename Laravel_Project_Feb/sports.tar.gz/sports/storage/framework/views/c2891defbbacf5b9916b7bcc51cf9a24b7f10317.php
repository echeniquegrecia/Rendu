<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet"   href= <?php echo e(asset('/css/prototype.css')); ?>>
</head>
<body>
<div id="stadium">
    <h1>Baseball News</h1>
    <h2>...because we know</h2>
    <div class="square"></div>
    <div class="square2">
        <nav>
            <ul>
                <li><a href= <?php echo e(url('register/')); ?>><?php echo app('translator')->getFromJson('messages.Register'); ?></a><li>
                <li><a href= <?php echo e(url('login/')); ?>><?php echo app('translator')->getFromJson('messages.Login'); ?></a><li>
                <li><a href= <?php echo e(url('playersRanking/')); ?>><?php echo app('translator')->getFromJson('messages.Players'); ?></a><li>
                <li><a href= <?php echo e(url('teamRanking/')); ?>><?php echo app('translator')->getFromJson('messages.Teams'); ?></a><li>
                <li><a href= <?php echo e(url('logout/')); ?>><?php echo app('translator')->getFromJson('messages.Logout'); ?></a><li>
                <li><a href= <?php echo e(route('locale', 'en')); ?>><?php echo app('translator')->getFromJson('messages.English'); ?></a><li>
                <li><a href= <?php echo e(route('locale', 'esp')); ?>><?php echo app('translator')->getFromJson('messages.Spanish'); ?></a><li>
                <li><a href= <?php echo e(route('locale', 'fr')); ?>><?php echo app('translator')->getFromJson('messages.French'); ?></a><li>
            </ul>
        </nav>
        <h8 id ="time"></h8>
        <img id ="arrow" src= <?php echo e(asset('/arrow.png')); ?>>
        <script type="text/javascript" src=<?php echo e(asset('/js/time.js')); ?>>
        </script>

        <table class ="tablefutureMatches">
            <tr>
                <th colspan="5">Future Matches</th>
            </tr>
            <?php $__currentLoopData = $match; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matchs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <td><a href="/team/<?php echo e($matchs->id_team_1); ?>"><?php echo e($tab2[$l]['t1']); ?></a></td>
                    <td><?php echo e($matchs->score_team_1); ?></td>
                    <td>-</td>
                    <td><?php echo e($matchs->score_team_2); ?></td>
                    <td><a href="/team/<?php echo e($matchs->id_team_2); ?>"><?php echo e($tab2[$l]['t2']); ?></a></td>
                <tr><td id = "detailsmatch" colspan="5"><a href="/match/<?php echo e($matchs->id); ?>">Match details</a></td></tr>
                <?php echo e($l++); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
        </table>
        <table class ="tableMatches">
            <tr>
                <th colspan="5">Last Matches</th>
            </tr>
            <?php $__currentLoopData = $matchpast; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $matchs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><a href="/team/<?php echo e($matchs->id_team_1); ?>"><?php echo e($tab1[$j]['t1']); ?></a></td>
                    <td><?php echo e($matchs->score_team_1); ?></td>
                    <td>-</td>
                    <td><?php echo e($matchs->score_team_2); ?></td>
                    <td><a href="/team/<?php echo e($matchs->id_team_2); ?>"><?php echo e($tab1[$j]['t2']); ?></a></td>
                <tr><td id = "detailsmatch" colspan="5"><a href="/matchpast/<?php echo e($matchs->id); ?>">Match details</a></td></tr>
                <?php echo e($j++); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tr>
        </table>
    </div>
    <img id ="ball" src= <?php echo e(asset('/ball.png')); ?>>
</div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>





