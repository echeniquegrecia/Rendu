<?php
return[

	"WELCOME IN OUR BASEBALL OFFICIAL SITE"=> "BIENVENIDO EN NUESTRA OFICIAL BEISBOL PAGINA",
	"Login"=> "Acceso",
	"Register"=> "Inscribirse",
	"Home"=> "Pagina principal",
	"Teams"=> "Equipos",
	"Players"=> "Jugadores",

	"E-Mail Address"=> "Correo Electronico",
	"Password"=> "Contrasena",
	"Remember Me"=> "Registrame",
	"Forgot Your Password?"=> "Contrasena Olvidada",
	"Name"=> "Nombre",
	"Confirm Password"=> "Confirma la Contrasena",
	"Dashboard"=>"Panel de Instrumentos",
	"Our players ranking"=> "Jugadores clasificacion",
	"Ranking"=> "Clasificacion",
	"You are logged in!"=> "Estas conectado!",
	"Individual description"=> "Detalle des jugador",
	"NAME"=>"NOMBRES DE LOS JUGADORES",
	"AGE"=> "EDAD",
	"HEIGHT"=> "ALTURA",
	"RANKING"=> "CLASIFICACION",
	"POSITION"=> "POSICION",
	"NATIONALITY"=> "NACIONALIDAD",
	"News"=> "Actualidad",
	"Lang"=> "Lengua",
	"English"=> "Ingles",
	"Spanish"=> "Español",
	"French"=>"Francés",
    "Connect your passion for the baseball with us!"=>"Conecta tu pasión por el béisbol con nosotros",
    "Register your passion for the baseball with us!"=>"Registra tu pasión por el béisbol con nosotros!",
    "Logout"=>"Desconectarse",


];