
<html>
<head>
    <title>Baseball News</title>
    <link rel="stylesheet" href='/Laravel_Project_Feb/sports/public/css/prototype.css'>
</head>
<body>
    <div id="stadium">
        <h1>Baseball News</h1>
        <h2>...because we know</h2>
        <div class="square"></div>
        <div class="square2">
            <nav>
                <ul>
                    <li>
                        <a font-family= "Verdana" href="login.php">Sign in</a>
                    </li>
                    <li>
                        <a href="login.php">Login</a>
                    </li>
                </ul>
            </nav>
        </div>
        <img src= "../../public/ball.png">
    </div>
<footer>Jean Pin - Grecia Echenique - Sibel Yegec. Paris 2018.</footer>
</body>
</html>





