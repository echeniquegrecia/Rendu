def display_all(dic):

    for key, value in dic.items():
        print ("([",value.__class__.__name__,"]:","[",str(value),"])")
