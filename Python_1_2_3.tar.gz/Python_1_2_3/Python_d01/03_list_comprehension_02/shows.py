def shows(dic):

    list1 = list()

    for key, value in dic.items():
        list1.insert(1,key).join('=>')
        a= "[%s]" % (','.join(list1))
    print (a)