def increment(list):

    list2 = []
    for i in range(0, len(list)):
        if list[i].__class__.__name__=='int':
            list2.append(list[i]+1)
        else:
            list2.append(list[i])


    print (list2)


