def double_return(data):

   list1 = list()
   list2 = list()

   for key, value in data.items():
        list1.insert(1, key)
        list2.insert(1, value)
   return list1, list2

