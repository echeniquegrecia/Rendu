def display_all(dic):

    for key, value in dic.items():
      print("[",key.__class__.__name__,"]->([",value.__class__.__name__,"]:","[",str(value),"])")
