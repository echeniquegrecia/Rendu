from required import REQUIRED

print (REQUIRED)