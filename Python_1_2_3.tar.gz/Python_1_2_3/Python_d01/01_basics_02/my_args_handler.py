import sys
def my_args_handler(*args):

    list = ""

    for string in range(0,len(args)):
        list += args[string]
        if string != len(args) - 1:
           list +=", "

    return list


