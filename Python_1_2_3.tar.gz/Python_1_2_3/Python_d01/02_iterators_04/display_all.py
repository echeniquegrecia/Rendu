def display_all(dic):

      i = 0
      for key, value in dic.items():
           print ("[",i,"]->([",value.__class__.__name__,"]:","[",str(value),"])")
           i = i + 1



