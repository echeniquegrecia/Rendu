def show_methods(a):

    print (dir(a))