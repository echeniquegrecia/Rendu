#!/usr/bin/python
import sys
length2 = len(sys.argv)
number = 0
letter= 0

for j in range(1,length2):
    for i in range(0,len(sys.argv[j])) :
        if sys.argv[j][i].isalpha():
           letter +=1
        elif sys.argv[j][i].isnumeric():
           number +=1

sum = letter + number

print (sum)










