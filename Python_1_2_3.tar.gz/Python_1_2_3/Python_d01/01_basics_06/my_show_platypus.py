#!/usr/bin/python

def my_show_platypus(nb):
    for i in range(0, nb):
        print('Platypus')
